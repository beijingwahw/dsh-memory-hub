import * as Schema from '@deepseek-ai/schemastery';
import { Context } from '@deepseek-ai/cordis';

/**
 * dsh-memory-hub 配置 Schema
 *
 * 使用 Cordis 生态的 schemastery 描述配置，插件在 cordis.patch.yml 中被安装后，
 * 用户可以通过 settings / profile patch 覆盖这些键。
 */

/** 自动捕获的保守程度 */
type CaptureMode = 'conservative' | 'balanced' | 'aggressive' | 'off';
/** 0.6.0：真实数据导入源（可选；未配置则插件行为与 0.5.0 完全一致） */
interface ImportSources {
    /** Markdown / 纯文本记忆文件路径（AGENTS.md、MEMORY.md、USER.md 等），启动时导入为显式记忆 */
    documents?: string[];
    /** Harness 会话事件 JSONL 日志路径，启动时导入为自动记忆 */
    sessionLogs?: string[];
}
interface MemoryHubConfig {
    /** 记忆存储目录（默认 ~/.dsh/memory-hub） */
    storageDir: string;
    /** 单条记忆最大字符数 */
    maxEntryChars: number;
    /** 召回默认 token 预算 */
    defaultRecallTokens: number;
    /** 召回默认条数上限 */
    defaultRecallLimit: number;
    /** 自动捕获模式（conservative/balanced/aggressive/off） */
    captureMode: CaptureMode;
    /** 自动捕获时同上：是否把摘要写入 tags */
    autoTags: boolean;
    /** 同一内容去重的时间窗口（ms）内视为重复 */
    dedupWindowMs: number;
    /** 记忆过期天数（0 表示永不过期） */
    ttlDays: number;
    /** 0.6.0：真实数据导入源（可选；缺失时行为与 0.5.0 完全一致） */
    importSources?: ImportSources;
}

declare const name = "dsh-memory-hub";
declare const inject: string[];
declare const Config: Schema.default<MemoryHubConfig>;
declare function apply(ctx: Context, config?: Partial<MemoryHubConfig>): () => Promise<void>;

export { Config, apply, inject, name };
