import * as Schema from '@deepseek-ai/schemastery';
import { Context } from '@deepseek-ai/cordis';

/**
 * dsh-memory-hub 配置 Schema
 *
 * 使用 Cordis 生态的 schemastery 描述配置，插件在 cordis.patch.yml 中被安装后，
 * 用户可以通过 settings / profile patch 覆盖这些键。
 */

/** 自动捕获的保守程度 */
type CaptureMode = 'conservative' | 'balanced' | 'aggressive' | 'off';
/** 0.6.0：真实数据导入源（可选；未配置则插件行为与 0.5.0 完全一致） */
interface ImportSources {
    /** Markdown / 纯文本记忆文件路径（AGENTS.md、MEMORY.md、USER.md 等），启动时导入为显式记忆 */
    documents?: string[];
    /** Harness 会话事件 JSONL 日志路径，启动时导入为自动记忆 */
    sessionLogs?: string[];
}
interface MemoryHubConfig {
    /** 记忆存储目录（默认 ~/.dsh/memory-hub） */
    storageDir: string;
    /** 单条记忆最大字符数 */
    maxEntryChars: number;
    /** 召回默认 token 预算 */
    defaultRecallTokens: number;
    /** 召回默认条数上限 */
    defaultRecallLimit: number;
    /** 自动捕获模式（conservative/balanced/aggressive/off） */
    captureMode: CaptureMode;
    /** 自动捕获时同上：是否把摘要写入 tags */
    autoTags: boolean;
    /** 同一内容去重的时间窗口（ms）内视为重复 */
    dedupWindowMs: number;
    /** 记忆过期天数（0 表示永不过期） */
    ttlDays: number;
    /** 0.9.0：召回评分时间衰减半衰期天数（0 = 关闭评分衰减，与 ttlDays=0「永不过期」哲学一致；>0 按天指数冷却） */
    recallDecayHalfLifeDays: number;
    /** 0.6.0：真实数据导入源（可选；缺失时行为与 0.5.0 完全一致） */
    importSources?: ImportSources;
    /**
     * 1.0.0：被取代记忆识别（DESIGN-1.0 模块 A）。
     * 'off'（默认，零行为变化）：不识别取代关系；
     * 'auto'：写入显式/导入记忆时检测语义对立信号（改用/升级到/instead of 等词面），
     *   给新记忆打 supersede:<旧id>、旧记忆打 superseded-by:<新id>，召回时被取代记忆降权。
     */
    supersedeMode: 'off' | 'auto';
    /**
     * 1.0.0：语义线叠加融合（DESIGN-1.0 模块 B）。
     * false（默认）：语义线仅在词面（含模糊）零命中时兜底 = 0.10.0 既有语义；
     * true：语义线与词面线叠加贡献（fusionMode='rrf' 时按 RRF 融合），提升真实问句召回。
     */
    semanticBoost: boolean;
    /** 1.0.0：语义线融合模式（默认 interpolate = 线性插值；rrf = Reciprocal Rank Fusion） */
    fusionMode: 'interpolate' | 'rrf';
    /** 1.0.0：记忆库条目上限（0 = 不限，默认）；超出时按价值分淘汰最低分非 instruction 记忆（需 autoEvict 开启） */
    maxEntries: number;
    /** 1.0.0：是否启用价值感知自动淘汰（默认 false；仅在 maxEntries>0 且超出时生效，instruction 永不自动淘汰） */
    autoEvict: boolean;
    /** 1.0.0：是否在 status/recall 输出主题聚类视图（默认 false，避免额外计算开销） */
    themes: boolean;
}

declare const name = "dsh-memory-hub";
declare const inject: string[];
declare const Config: Schema.default<MemoryHubConfig>;
declare function apply(ctx: Context, config?: Partial<MemoryHubConfig>): () => Promise<void>;

export { Config, apply, inject, name };
